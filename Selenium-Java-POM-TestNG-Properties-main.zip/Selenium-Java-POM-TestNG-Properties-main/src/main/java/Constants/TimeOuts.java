package Constants;

public class TimeOuts {
	public static long DEFAULT_TIMEOUT=10;
	public static int SWITCH_WINDOW_TIMEOUT=5;

}
